﻿using System;
using System.Collections;
using System.Linq;

namespace ConsoleApp1
{
    class Program
    {
        public static void Main(string[] args)
        {

            try
            {
                String line, word = "";
                int count = 0, maxCount = 0;
                ArrayList words = new ArrayList();

                //Opens the 2600-0 file online.
                //i have added my own text file online, please comment out your txt file online. it was taking long to read the entire file. my txt has a fewer words 
                //I think it is worth mentioning that for large data a different approach could be used, since keeping exact frequency counts of words is too time consuming.
                System.IO.StreamReader file = new System.IO.StreamReader(@"D:\ConsoleApp1\2600-0.txt");


                Console.WriteLine("Console in C#\r");
                Console.WriteLine("------------------------\n");

                // Ask the user to type the first number.
                Console.WriteLine("Type a Word, and then press Enter");
                word = (Console.ReadLine());

                //Reads each line  
                while ((line = file.ReadLine()) != null)
                {
                    String[] string1 = line.ToLower().Split(new Char[] { ',', '.', ' ' }, StringSplitOptions.RemoveEmptyEntries);
                    //Adding all words generated in previous step into words  
                    foreach (String s in string1)
                    {
                        words.Add(s);
                    }
                }

                //Determine the most repeated word in a file  
                for (int i = 0; i < words.Count; i++)
                {
                    count = 1;
                    //Count each word in the file and store it in variable count  
                    for (int j = i + 1; j < words.Count; j++)
                    {
                        if (words[i].Equals(words[j]))
                        {
                            count++;
                        }
                    }
                    //If maxCount is less than count then store value of count in maxCount   
                    //and corresponding word to variable word  
                    if (count > maxCount)
                    {
                        maxCount = count;
                        word = (String)words[i];
                    }
                }

                Console.WriteLine("Most repeated word: " + word.ToUpper());
                Console.WriteLine("Repeated: " + maxCount);
                file.Close();


                /*  string num1 = "Hello World This is a great world, This World is simply great".ToLower();
                  string num2 = "Hello World This is a great world, This World is simply great".ToLower();
                  string words = "Hello World This is a great world, This World is simply great".ToLower();
                  // Display title as the C# console calculator app.
                  Console.WriteLine("Console  in C#\r");
                  Console.WriteLine("------------------------\n");
                 
                // Ask the user to type the first number.
                  Console.WriteLine("Type a Word, and then press Enter");
                  num1 = (Console.ReadLine());
                
                
                var results = num1.Split(' ').Where(x => x.Length > 3)
                                                .GroupBy(x => x)
                                                .Select(x => new { Count = x.Count(), num1 = x.Key })
                                                .OrderByDescending(x => x.Count);
                  foreach (var item in results)
                  {
                      Console.WriteLine(String.Format("{0} occured {1} times", item.num1, item.Count));

                      break;*/
                /* Console.WriteLine(String.Format("{0} occured {1} times", item.Word, item.Count));
                 Console.WriteLine($"Your result: {num1} + {num2} = " + (num1 + num2));
                 break;
                 Console.WriteLine(String.Format("{0} occured {1} times", item.Word, item.Count));
                 Console.WriteLine($"Your result: {num1} - {num2} = " + (num1 - num2));
                 break;
                 Console.WriteLine(String.Format("{0} occured {1} times", item.Word, item.Count));
                 Console.WriteLine($"Your result: {num1} * {num2} = " + (num1 * num2));
                 break;
                 Console.WriteLine(String.Format("{0} occured {1} times", item.Word, item.Count));
                 Console.WriteLine($"Your result: {num1} / {num2} = " + (num1 / num2));
                 break;*/

                /* }
                 // Wait for the user to respond before closing.
                 Console.Write("Press any key to close the this console app...");
                 Console.ReadKey();
                 //Console.ReadLine();

                 */

            }
            catch (Exception ex)
            {

                Console.Write(ex.Message);
            }
        }
    }
}
