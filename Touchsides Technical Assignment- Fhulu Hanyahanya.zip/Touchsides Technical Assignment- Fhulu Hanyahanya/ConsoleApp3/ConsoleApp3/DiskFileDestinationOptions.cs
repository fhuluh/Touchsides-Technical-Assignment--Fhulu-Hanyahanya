﻿namespace ConsoleApp3
{
    internal class DiskFileDestinationOptions
    {
    }
}