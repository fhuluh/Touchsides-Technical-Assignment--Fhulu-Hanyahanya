﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace ConsoleApp3
{
    class Program
    {

        //
        /// <summary>
        ///
        /// 
        /// </summary>
        private static readonly char[] delimiters = { ' ', '.', ',', ';', '\'', '-', ':', '!', '?', '(', ')', '<', '>', '=', '*', '/', '[', ']', '{', '}', '\\', '"', '\r', '\n' };
        private static readonly Func<string, string> theWord = Word;
        private static readonly Func<IGrouping<string, string>, KeyValuePair<string, int>> theNewWordCount = NewWordCount;
        private static readonly Func<KeyValuePair<string, int>, int> theCount = Count;


        private static string Word(string word)
        {
            return word;
        }
        private static KeyValuePair<string, int> NewWordCount(IGrouping<string, string> wordCount)
        {
            return new KeyValuePair<string, int>(wordCount.Key, wordCount.Count());
        }
        private static int Count(KeyValuePair<string, int> wordCount)
        {
            return wordCount.Value;
        }


        static void Main(string[] args)
        {

            /*string filepath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            filepath = "C:\\" + "ConsoleApp3\\" + " 2600-0.txt";
            if (!Directory.Exists(filepath))
            {
                Directory.CreateDirectory(filepath);
            }*/
            foreach (var wordCount in File.ReadAllText(args.Length > 0 ? args[0] : @"D:\ConsoleApp3\2600-0.txt")
                .Split(delimiters, StringSplitOptions.RemoveEmptyEntries)
                .AsParallel()
                .GroupBy(theWord, StringComparer.OrdinalIgnoreCase)
                .Select(theNewWordCount)
                .OrderByDescending(theCount))
            {
                Console.WriteLine(
                    "Word: \"" 
                    + wordCount.Key
                    + "\" occurred: " + " -- "
                    + wordCount.Value + " Time"+"(s)");
            }

            Console.ReadLine();
        }







    }
}
